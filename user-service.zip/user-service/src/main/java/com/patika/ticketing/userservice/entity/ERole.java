package com.patika.ticketing.userservice.entity;

public enum ERole {

    ROLE_USER,
    ROLE_ADMIN

}
