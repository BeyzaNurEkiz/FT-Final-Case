package com.patika.ticketing.userservice.service;

import com.patika.ticketing.userservice.entity.dto.request.LoginRequest;
import com.patika.ticketing.userservice.entity.dto.response.JwtResponse;
import com.patika.ticketing.userservice.utils.result.DataResult;

public interface AuthService {

    DataResult<JwtResponse> authenticateUser(LoginRequest loginRequest);
}
